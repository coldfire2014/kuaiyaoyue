var windowWidth;
var windowHeight;
var isPC = navigator.platform.indexOf("Win") >= 0 ? !0 : !1;

Zepto(function($) {
    console.log("zepto is ready at " + (new Date()).getTime());
    var $window = $(window);

    var resetSlides = function() {
        //设置滑动窗大小
        windowWidth = $window.get(0).innerWidth;
        windowHeight = $window.get(0).innerHeight;
        var bgWidth = windowWidth / 480;

        

        $("#slide").css({
            width: windowWidth,
            height: windowHeight
        });
        $("#slide > .pages").css({
            width: windowWidth,
            height: windowHeight
        });
        $("#slide > .pages > section").css({
            width: windowWidth,
            height: windowHeight
        });

        $("#musicDiv").css("left", windowWidth - 60 + "px");
        $("#infos_div").css("width",  bgWidth* 450 + "px");
        $("#btn_enroll").css("top",windowHeight-75*bgWidth+"px")
                .css("width",bgWidth*378+"px")
                .css("height",bgWidth*54+"px")
                .css("line-height",bgWidth*54+"px");
        $("#enroll_div").css("width", bgWidth * 450 + "px");

        //向上箭头初始化先不显示
        $("#slide > .slideArrow").removeClass("enabled");

        var sections = $("#slide > .pages > section");
        var sectionsLength = sections ? sections.length: 0;

        //如果有页面
        if (0 < sectionsLength) {
            //获取标记为当前页的页面
            var currentPage = $("#slide > .pages > section.present");

            //如果没有标记为当前页面或标记为当前页的页面数不等于1
            if (!currentPage || 1 != currentPage.length) {
                //清除当前页标记，上一页标记，下一页标记
                $("#slide > .pages > section").removeClass("present");
                $("#slide > .pages > section").removeClass("future");
                $("#slide > .pages > section").removeClass("past");

                //标记第一页为当前页
                var firstSection = $("#slide > .pages > section:first").addClass("present");
                //如果总页面数多余1页则标记接下来的一页为下一页，并且使向上的箭头可用
                if (1 < sectionsLength) {
                    firstSection.next().addClass("future");
                    $("#slide > .slideArrow").addClass("enabled");
                }
            }
            //有标记为当前页的页面且只有一个
            else {
                //清除上一页，下一页标记
                $("#slide > .pages > section").removeClass("future");
                $("#slide > .pages > section").removeClass("past");

                //下一页存在
                var futurePage = currentPage.next();
                if (futurePage && 1 == futurePage.length) {
                    futurePage.addClass("future");
                    $("#slide > .slideArrow").addClass("enabled");
                }
                //上一页存在
                var pastPage = currentPage.prev();
                if (pastPage && 1 == pastPage.length) {
                    pastPage.addClass("past");
                }
            }
        }
    };

    //显示下一页
    var showNextPage = function() {
        //获取标记为当前页的页面
        var currentPage = $("#slide > .pages > section.present");
        //获取标记为当前页的页面的下一页
        var nextPage = currentPage.next();
        if (nextPage && 1 == nextPage.length) {
            //清除下一页标记和上一页标记
            $("#slide > .pages > section").removeClass("future");
            $("#slide > .pages > section").removeClass("past");
            //将原来标记当前页的页面标记为上一页
            currentPage.removeClass("present");
            currentPage.addClass("past");
            //原来标记为下一页的页面标记为当前页
            nextPage.addClass("present");

            //获取即将标记为下一页的页面
            var futurePage = nextPage.next();
            if (futurePage && 1 == futurePage.length) {
                //标记为下一页，且向上箭头可用
                futurePage.addClass("future");
                $("#slide > .slideArrow").addClass("enabled");
            } else {
                $("#slide > .slideArrow").removeClass("enabled");
            }
        }
    };

    //显示上一页
    var showPrevPage = function() {
        //获取标记为当前页的页面
        var currentPage = $("#slide > .pages > section.present");
        //获取标记为当前页的页面的上一页
        var prevPage = currentPage.prev();
        if (prevPage && 1 == prevPage.length) {
            //清除下一页标记和上一页标记
            $("#slide > .pages > section").removeClass("future");
            $("#slide > .pages > section").removeClass("past");
            //将原来标记当前页的页面标记为下一页
            currentPage.removeClass("present");
            currentPage.addClass("future");
            //原来标记为上一页的页面标记为当前页
            prevPage.addClass("present");
            //获取即将标记为上一页的页面
            var pastPage = prevPage.prev();
            if (pastPage && 1 == pastPage.length) {
                pastPage.addClass("past");
            }
            $("#slide > .slideArrow").addClass("enabled");
        }
    };

    /*初始化滑动*/
    var initSwip = function() {
        /*
        $('#slide').swipeUp(function(e){
          showNextPage();
          //e.preventDefault(); 
        });
        $('#slide').swipeDown(function(e){
          showPrevPage();
          //e.preventDefault(); 
        });
        */

        var sargs = {
            iniL: 30,
            //X方向滑动的最小距离
            iniT: 500,
            //Y方向滑动的最大距离
            eCallback: function(tPoint) {
                switch (tPoint.direction) {
                case "up":
                    showNextPage();
                    break;
                case "down":
                    showPrevPage();
                }
            }
        };
        $("#slide").Swipe(sargs);
    };

    /*加载延迟加载的图片*/
    var loadLazyImg = function() {
        $(".lazyBgImg").each(function(index) {
            $this = $(this);
            var backgroundImage = $this.attr("data-bg-img");
            if (backgroundImage && 0 < backgroundImage.length) {
                var backgroundImageUrl = "url(" + backgroundImage + ")";
                $this.css("background-image", backgroundImageUrl);
            }
        });
        var timeout = setTimeout(function() {
            $(".lazyBgImg0").each(function(index) {
                $this = $(this);
                var backgroundImage = $this.attr("data-bg-img");
                if (backgroundImage && 0 < backgroundImage.length) {
                    var backgroundImageUrl = "url(" + backgroundImage + ")";
                    $this.css("background-image", backgroundImageUrl);
                }
            });
        },
        1000);
        var timeoutFirst = setTimeout(function() {
            $(".lazyBgImg1").each(function(index) {
                $this = $(this);
                var backgroundImage = $this.attr("data-bg-img");
                if (backgroundImage && 0 < backgroundImage.length) {
                    var backgroundImageUrl = "url(" + backgroundImage + ")";
                    $this.css("background-image", backgroundImageUrl);
                }
            });
        },
        3000);
    };

    $window.on("load",
    function() {
        console.log("window is ready at " + (new Date()).getTime());
        //$("#loadingPage").remove();
        var timeout = setTimeout(function() {
            resetSlides();
            $("#loadingPage").remove();
            loadLazyImg();
            initSwip();
        },
        100);
    });
});

function btn_enroll_click_func() {
    $("#slide > .slideArrow").removeClass("enabled");
    $("#musicDiv").css("display", "none");
    $("#btn_enroll").css("display", "none");
    $("#infos_div").removeClass("infos_show").addClass("infos_down");
    $("#enroll_div").css("display", "block").removeClass("enroll_show").addClass("enroll_down");
}

function enroll_close_click_func() {
    $("#infos_div").removeClass("infos_down").addClass("infos_show");
    $("#enroll_div").css("display", "none").removeClass("enroll_down").addClass("enroll_show");
    $("#slide > .slideArrow").addClass("enabled");
    $("#musicDiv").css("display", "block");
    $("#btn_enroll").css("display", "block");
}

$("#btn_enroll").on("click", btn_enroll_click_func);
$("#enroll_close_div").on("click", enroll_close_click_func);

// 微信分享的数据
var wechatData;
/*
    wechatData = {
      "title" : "吴阳冰和陈沁"
      "desc" : "诚挚邀请您来参加我们的婚礼， 2014年10月2号周四晚六点，席设囯惠大酒楼",
      "imgUrl" : "http://192.168.1.99:8080/test/userfiles/logo.jpg",
      "link" : window.location.href
    };
    */

Zepto(function($) {
    var dataWechatCallbackUrl = $("input[data-wechat-callback-url]").val();
    var dataWechatShareImg = $("[data-wechat-share-img]").val();

    if (!wechatData) {
        wechatData = {};
    }
    if (!wechatData.link) {
        wechatData.link = window.location.href;
    }
    if (!wechatData.title) {
        wechatData.title = $('title').text();
    }
    if (!wechatData.desc) {
        wechatData.desc = $('meta[name="description"]').eq(0).attr('content');
    }
    if (!wechatData.imgUrl && dataWechatShareImg) {
        wechatData.imgUrl = dataWechatShareImg;
    }

    // 分享的回调
    var wechatCallback = {
        // 分享操作开始之前
        ready: function() {
            // 你可以在这里对分享的数据进行重组
            //alert("准备分享");
        },
        // 分享被用户自动取消
        cancel: function(resp) {
            // 你可以在你的页面上给用户一个小Tip，为什么要取消呢？
            //alert("分享被取消，msg=" + resp.err_msg);
        },
        // 分享失败了
        fail: function(resp) {
            // 分享失败了，是不是可以告诉用户：不要紧，可能是网络问题，一会儿再试试？
            //alert("分享失败，msg=" + resp.err_msg);
        },
        // 分享成功
        confirm: function(resp) {
            // 分享成功了，我们是不是可以做一些分享统计呢？
            //alert("分享成功，msg=" + resp.err_msg);
            if (dataWechatCallbackUrl) {
                window.location.href = dataWechatCallbackUrl;
            }
        },
        // 整个分享过程结束
        all: function(resp, shareTo) {
            // 如果你做的是一个鼓励用户进行分享的产品，在这里是不是可以给用户一些反馈了？
            //alert("分享" + (shareTo ? "到" + shareTo : "") + "结束，msg=" + resp.err_msg);
        }
    };

    var onBridgeReady = function() {
        WeixinJSBridge.on('menu:share:appmessage',
        function(argv) {
            wechatCallback.ready(argv);
            WeixinJSBridge.invoke('sendAppMessage', {
                "img_width": "640",
                "img_height": "640",
                "title": wechatData.title,
                "desc": wechatData.desc,
                "link": wechatData.link,
                "img_url": wechatData.imgUrl
            },
            function(resp) {
                switch (resp.err_msg) {
                    // send_app_msg:cancel 用户取消
                case 'send_app_msg:cancel':
                    wechatCallback.cancel && wechatCallback.cancel(resp);
                    break;
                    // send_app_msg:confirm 发送成功
                case 'send_app_msg:confirm':
                case 'send_app_msg:ok':
                    wechatCallback.confirm && wechatCallback.confirm(resp);
                    break;
                    // send_app_msg:fail　发送失败
                case 'send_app_msg:fail':
                default:
                    wechatCallback.fail && wechatCallback.fail(resp);
                    break;
                }
                // 无论成功失败都会执行的回调
                wechatCallback.all && wechatCallback.all(resp);
            });
        });

        WeixinJSBridge.on('menu:share:timeline',
        function(argv) {
            wechatCallback.ready(argv);
            WeixinJSBridge.invoke('shareTimeline', {
                "img_width": "640",
                "img_height": "640",
                "title": wechatData.title,
                "desc": wechatData.desc,
                "link": wechatData.link,
                "img_url": wechatData.imgUrl
            },
            function(resp) {
                switch (resp.err_msg) {
                    // share_timeline:cancel 用户取消
                case 'share_timeline:cancel':
                    wechatCallback.cancel && wechatCallback.cancel(resp);
                    break;
                    // share_timeline:confirm 发送成功
                case 'share_timeline:confirm':
                case 'share_timeline:ok':
                    wechatCallback.confirm && wechatCallback.confirm(resp);
                    break;
                    // share_timeline:fail　发送失败
                case 'share_timeline:fail':
                default:
                    wechatCallback.fail && wechatCallback.fail(resp);
                    break;
                }
                // 无论成功失败都会执行的回调
                wechatCallback.all && wechatCallback.all(resp);
            });
        });

    };

    if (document.addEventListener) {
        document.addEventListener("WeixinJSBridgeReady", onBridgeReady, false);
    } else if (document.attachEvent) {
        document.attachEvent("WeixinJSBridgeReady", onBridgeReady);
        document.attachEvent("onWeixinJSBridgeReady", onBridgeReady);
    }
});