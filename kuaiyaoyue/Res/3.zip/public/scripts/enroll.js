Zepto(function($) {
	
    var bgWidth = $(window).get(0).innerWidth;
    $("#btns").css("left", bgWidth - 60 + "px");

    function replyFunc() {
        //var dataStr = "{\"groom\":\"张无忌\", \"bride\":\"赵敏\", \"date\":\"2014.10.02 周四\", \"address\":\"国惠大酒楼(五里亭)一层 吉祥厅\", \"location\":\"福州市 晋安区 福马路 199-1\", \"images\":[\"http://vw.faw-vw.com/images/kv/pic_cc_big.jpg\", \"http://vw.faw-vw.com/images/vwbrand/newscontent/2014-03-20/new20140320_2.jpg\"]}";
        //changeUserInfo(dataStr);
        $("#loadingDiv").css("display", "block");
        $("#enroll_btn").off("click", replyFunc);
        var name = $("#replyName").val();
        var mobile = $("#replyMobile").val();
        var number = $("#replyNumber").val();
        var message = $("#replyMessage").val();

        if (name == "") {
            $("#enroll_btn").on("click", replyFunc);
            $("#loadingDiv").css("display", "none");
            $("#resultMessageDiv").html("姓名不能为空");
            $("#resultBtn").html("重新填写").click(function() {
                $("#resultDiv").css("display", "none");

            });
            $("#resultDiv").css("display", "block").css("background-image", "url(../public/failure.png)");
            $("#enroll_btn").on("click", replyFunc);
            $("#loadingDiv").css("display", "none");
            $("#resultCloseBtn").click(function() {
                $("#resultDiv").css("display", "none");
            });

            return;
        } else {
            var chinese = /^[\Α-\￥]+$/;
            if (chinese.test(name)) {
                if (name.length > 5) {
                    $("#enroll_btn").on("click", replyFunc);
                    $("#loadingDiv").css("display", "none");
                    $("#resultMessageDiv").html("中文名长度不能超过5个字");
                    $("#resultBtn").html("重新填写").click(function() {
                        $("#resultDiv").css("display", "none");
                    });
                    $("#resultDiv").css("display", "block").css("background-image", "url(../public/failure.png)");
                    $("#enroll_btn").on("click", replyFunc);
                    $("#loadingDiv").css("display", "none");
                    $("#resultCloseBtn").click(function() {
                        $("#resultDiv").css("display", "none");
                    });
                    return;
                }
            } else {
                if (name.length > 16) {
                    $("#enroll_btn").on("click", replyFunc);
                    $("#loadingDiv").css("display", "none");
                    $("#resultMessageDiv").html("英文名长度不能超过16个字母");
                    $("#resultBtn").html("重新填写").click(function() {
                        $("#resultDiv").css("display", "none");
                    });
                    $("#resultDiv").css("display", "block").css("background-image", "url(../public/failure.png)");
                    $("#enroll_btn").on("click", replyFunc);
                    $("#loadingDiv").css("display", "none");
                    $("#resultCloseBtn").click(function() {
                        $("#resultDiv").css("display", "none");
                    });
                    return;
                }
            }
        }

        if (number == "") {
            $("#enroll_btn").on("click", replyFunc);
            $("#loadingDiv").css("display", "none");
            $("#resultMessageDiv").html("参加人数不能为空");
            $("#resultBtn").html("重新填写").click(function() {
                $("#resultDiv").css("display", "none");

            });
            $("#resultDiv").css("display", "block").css("background-image", "url(../public/failure.png)");
            $("#enroll_btn").on("click", replyFunc);
            $("#loadingDiv").css("display", "none");
            $("#resultCloseBtn").click(function() {
                $("#resultDiv").css("display", "none");
            });
            return;
        }

        var regNum = /^(-|\+)?\d+$/;
        if (!regNum.test(number)) {
            $("#enroll_btn").on("click", replyFunc);
            $("#loadingDiv").css("display", "none");
            $("#resultMessageDiv").html("报名人数只能输入数字");
            $("#resultBtn").html("重新填写").click(function() {
                $("#resultDiv").css("display", "none");

            });
            $("#resultDiv").css("display", "block").css("background-image", "url(../public/failure.png)");
            $("#enroll_btn").on("click", replyFunc);
            $("#loadingDiv").css("display", "none");
            $("#resultCloseBtn").click(function() {
                $("#resultDiv").css("display", "none");
            });
            return;
        } else {
            if (parseInt(number) > 999) {
                $("#enroll_btn").on("click", replyFunc);
                $("#loadingDiv").css("display", "none");
                $("#resultMessageDiv").html("报名人数不能超过999个");
                $("#resultBtn").html("重新填写").click(function() {
                    $("#resultDiv").css("display", "none");
                });
                $("#resultDiv").css("display", "block").css("background-image", "url(../public/failure.png)");
                $("#enroll_btn").on("click", replyFunc);
                $("#loadingDiv").css("display", "none");
                $("#resultCloseBtn").click(function() {
                    $("#resultDiv").css("display", "none");
                });
                return;
            }
        }

        if (number < 0) {
            $("#enroll_btn").on("click", replyFunc);
            $("#loadingDiv").css("display", "none");
            $("#resultMessageDiv").html("报名人数不能为负数");
            $("#resultBtn").html("重新填写").click(function() {
                $("#resultDiv").css("display", "none");

            });
            $("#resultDiv").css("display", "block").css("background-image", "url(../public/failure.png)");
            $("#enroll_btn").on("click", replyFunc);
            $("#loadingDiv").css("display", "none");
            $("#resultCloseBtn").click(function() {
                $("#resultDiv").css("display", "none");
            });
            return;
        }

        var rephone = /^((\(\d{2,3}\))|(\d{3}\-))?(\(0\d{2,3}\)|0\d{2,3}-)?[1-9]\d{6,7}(\-\d{1,4})?$/;
        var remobile = /^(13|15|18)\d{9}$/;
        if (mobile != "" && !(rephone.test(mobile) || remobile.test(mobile))) {
            $("#enroll_btn").on("click", replyFunc);
            $("#loadingDiv").css("display", "none");
            $("#resultMessageDiv").html("请输入正确的电话号码！");
            $("#resultBtn").html("重新填写").click(function() {
                $("#resultDiv").css("display", "none");

            });
            $("#resultDiv").css("display", "block").css("background-image", "url(../public/failure.png)");
            $("#enroll_btn").on("click", replyFunc);
            $("#loadingDiv").css("display", "none");
            $("#resultCloseBtn").click(function() {
                $("#resultDiv").css("display", "none");
            });
            return;
        }

        if (message != "" && message.length > 70) {
            $("#enroll_btn").on("click", replyFunc);
            $("#loadingDiv").css("display", "none");
            $("#resultMessageDiv").html("留言的长度最多只能是70个字，请重新输入");
            $("#resultBtn").html("重新填写").click(function() {
                $("#resultDiv").css("display", "none");

            });
            $("#resultDiv").css("display", "block").css("background-image", "url(../public/failure.png)");
            $("#enroll_btn").on("click", replyFunc);
            $("#loadingDiv").css("display", "none");
            $("#resultCloseBtn").click(function() {
                $("#resultDiv").css("display", "none");
            });
            return;
        }

        $.ajax({
            type: 'POST',
            url: '../../nozzle/NefRegistration/enlist.aspx',
            data: JSON.stringify({
                unquieId: uniqueId,
                name: name,
                mobile: mobile,
                number: number,
                message: message
            }),
            contentType: "application/json;charset=utf-8",
            dataType: 'json',
            timeout: 60000,
            context: $('body'),
            success: function(data) {
                $("#resultDiv").css("display", "block").css("background-image", "url(../public/success.png)");
                $("#resultMessageDiv").html("报名成功");
                $("#resultBtn").html("下载APP").click(function() {
                    location.href = "http://download.kyy121.com/temp/download.jsp?appId=kyy";
                });
                $("#enroll_btn").on("click", replyFunc);
                $("#loadingDiv").css("display", "none");
                $("#resultCloseBtn").click(function() {
                    $("#resultDiv").css("display", "none");
                    close_div_click_func();
                    $("#btn_enroll").html("已报名");
                    $("#btn_enroll").off("click", btn_enroll_click_func);
                    $("#enroll_btn").html("报名成功");
                    $("#enroll_btn").off("click", replyFunc);
                });
            },
            error: function(xhr, type) {
                if (500 == xhr.status) {
                    var errorStr = "";
                    var errorCode = 0;
                    var errorData = JSON.parse(xhr.responseText);
                    if (errorData && errorData.error && 33 == errorData.error.code && errorData.error.subErrors) {
                        var subErrors = errorData.error.subErrors;
                        var subErrorLength = subErrors.length;
                        for (var i = 0; i < subErrorLength; i++) {
                            var errorMessage = subErrors[i].message;
                            var errorArr = errorMessage.split(":");
                            errorStr += errorArr[2] + "\n";
                        }
                    } else if (errorData && errorData.error && 83 == errorData.error.code && errorData.error.subErrors) {
                        var subErrors = errorData.error.subErrors;
                        var subErrorLength = subErrors.length;
                        for (var i = 0; i < subErrorLength; i++) {
                            var errorMessage = subErrors[i].message;
                            errorStr += errorMessage + "\n";
                        }
                    }
                    errorCode = errorData.error.code;
                    if (!errorStr) {
                        // errorStr = "报名失败";
                        // alert(errorStr);
                    }
                    if (errorCode == 83) {
                        $("#resultDiv").css("display", "block").css("background-image", "url(../public/warning.png)");
                        $("#resultMessageDiv").html("报名已结束");
                        $("#resultBtn").html("下载APP").click(function() {
                            location.href = "http://download.kyy121.com/temp/download.jsp?appId=kyy";
                        });
                    } else if (errorCode == 33) {
                        $("#resultDiv").css("display", "block").css("background-image", "url(../public/failure.png)");
                        $("#resultMessageDiv").html("信息填写有误，请重新填写！");
                        $("#resultBtn").html("重新填写").click(function() {
                            $("#resultDiv").css("display", "none");
                        });
                    } else {
                        $("#resultDiv").css("display", "block").css("background-image", "url(../public/failure.png)");
                        $("#resultMessageDiv").html("报名失败");
                        $("#resultBtn").html("重新报名").click(function() {
                            $("#resultDiv").css("display", "none");
                            replyFunc();
                        });
                    }
                    $("#enroll_btn").on("click", replyFunc);
                    $("#loadingDiv").css("display", "none");
                    $("#resultCloseBtn").click(function() {
                        $("#resultDiv").css("display", "none");
                        if (errorCode == 83) {
                            close_div_click_func();
                        }
                    });
                }
                $("#enroll_btn").on("click", replyFunc);
                $("#loadingDiv").css("display", "none");
            }
        });
    }

    $("#enroll_btn").on("click", replyFunc);
    if(enrollCloseTimestamp!=""&&(parseFloat(enrollCloseTimestamp)<new Date().getTime())){
    	$("#enroll_btn").off("click", replyFunc);
    }
});